import 'package:flutter/material.dart';
import 'package:trabalho1/pages/new_person.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, String>> peopleList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('List of People', style: TextStyle(color: Colors.white),),
        centerTitle: true,
        backgroundColor: const Color.fromRGBO(0, 12, 102, 1),
      ),
      body: peopleList.isEmpty
          ? const Center(
              child: Text(
                'No people added yet.',
                style: TextStyle(fontSize: 18),
              ),
            )
          : ListView.builder(
              itemCount: peopleList.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(peopleList[index]['name'] ?? ''),
                  subtitle: Text(peopleList[index]['phone'] ?? ''),
                  trailing: Text(peopleList[index]['email'] ?? ''),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newPerson = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NewPersonPage()),
          );

          if (newPerson != null) {
            setState(() {
              peopleList.add(newPerson);
            });
          }
        },
        backgroundColor: const Color.fromRGBO(0, 12, 102, 1),
        child: const Icon(Icons.add, color: Colors.white,),
      ),
    );
  }
}
